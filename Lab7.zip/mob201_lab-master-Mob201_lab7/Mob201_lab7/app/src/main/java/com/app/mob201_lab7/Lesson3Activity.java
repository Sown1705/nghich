package com.app.mob201_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Lesson3Activity extends AppCompatActivity {
    ImageView ivHour, ivMinute, ivSecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_3);
        ivHour = findViewById(R.id.iv_hour);
        ivMinute = findViewById(R.id.iv_minute);
        ivSecond = findViewById(R.id.iv_second);
        startClock();
    }

    public void startClock() {
        Animation animHour = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.hour);
        Animation animMinute = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.minute);
        Animation animSecond = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.second);
        ivHour.startAnimation(animHour);
        ivMinute.startAnimation(animMinute);
        ivSecond.startAnimation(animSecond);

    }
}