package com.app.mob201_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class Lesson2Activity extends AppCompatActivity {
    ImageView imageView;
    Button btnAll, btnDoraemon, btnNobita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_2);

        imageView = findViewById(R.id.iv_less2);
        btnAll = findViewById(R.id.btn_all);
        btnDoraemon = findViewById(R.id.btn_doraemon);
        btnNobita = findViewById(R.id.btn_nobita);

        btnAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.all);
                start();
            }
        });
        btnDoraemon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.doraemon);
                start();
            }
        });
        btnNobita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setImageResource(R.drawable.nobita);
                start();
            }
        });

    }
    private void start(){
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_show);
        imageView.startAnimation(animation);
    }
}