package com.app.mob201_lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class Lesson1Activity extends AppCompatActivity {
    ImageView imageView;
    Button btnRotation, btnMoving, btnZoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_1);
        imageView = findViewById(R.id.iv_less1);
        btnRotation = findViewById(R.id.btn_rotation);
        btnMoving = findViewById(R.id.btn_moving);
        btnZoom = findViewById(R.id.btn_zoom);

        btnRotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int dest = 360;
                if (imageView.getRotation() == 360) {
                    System.out.println(imageView.getAlpha());
                    dest = 0;
                }
                ObjectAnimator animator = ObjectAnimator.ofFloat(imageView, "rotation", dest);
                animator.setDuration(2000);
                animator.start();
            }
        });

        btnMoving.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.moving);
                imageView.startAnimation(animation);
            }
        });

        btnZoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
                imageView.startAnimation(animation);
            }
        });
    }
}